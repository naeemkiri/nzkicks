import React, { useState, useEffect, useRef, useMemo } from 'react';
import neon1 from 'container:///mnt/data/src/assets/8387424de4c68da2-image_20261031_225338.webp';
import neon2 from 'container:///mnt/data/src/assets/a04913dd3e0d1729-image_20261031_225338_1.webp';
import neon3 from 'container:///mnt/data/src/assets/cd8a75bea2831f90-image_20261031_225338_2.webp';
import neon4 from 'container:///mnt/data/src/assets/ed0f6d56cba0eb97-image_20261031_225338_3.webp';
import neon5 from 'container:///mnt/data/src/assets/7ff9219c0ab55dc3-image_20261031_225339.webp';
import neon6 from 'container:///mnt/data/src/assets/dca0ebd9441f7259-image_20261031_225341.webp';
import neon7 from 'container:///mnt/data/src/assets/3f42f023027e29d8-image_20261031_225344.webp';
import neon8 from 'container:///mnt/data/src/assets/4b0175c7c35cd8d6-image_20261031_225352.webp';

type Product = {
  id: number;
  name: string;
  baseUsd: number;
  finalPrice: number;
  img: string;
  badge: string;
  stock: string;
};

type CartItem = Product & { size: number; qty: number };

type OrderRecord = {
  id: string;
  customer: { name: string; phone: string; address: string; city: string };
  items: { name: string; size: number; qty: number; price: number }[];
  total: number;
  hiddenAmount: number;
  targetAccount: string;
  status: string;
  createdAt: string;
};

const NEON = [neon1, neon2, neon3, neon4, neon5, neon6, neon7, neon8];

const PRODUCTS: Product[] = [
  { id: 1, name: "Dunk Low Panda", baseUsd: 38, finalPrice: 8999, img: NEON[0], badge: "PICK 01", stock: "In stock" },
  { id: 2, name: "Jordan 1 Bred", baseUsd: 42, finalPrice: 9899, img: NEON[1], badge: "PICK 02", stock: "Few left" },
  { id: 3, name: "Air Force 1 White", baseUsd: 35, finalPrice: 8299, img: NEON[2], badge: "PICK 03", stock: "In stock" },
  { id: 4, name: "Yeezy Boost 350", baseUsd: 40, finalPrice: 9499, img: NEON[3], badge: "PICK 04", stock: "In stock" },
  { id: 5, name: "New Balance 550", baseUsd: 39, finalPrice: 9199, img: NEON[4], badge: "PICK 05", stock: "In stock" },
  { id: 6, name: "Jordan 4 Military Black", baseUsd: 45, finalPrice: 10499, img: NEON[5], badge: "PICK 06", stock: "Low stock" },
  { id: 7, name: "SB Dunk Low", baseUsd: 37, finalPrice: 8699, img: NEON[6], badge: "PICK 07", stock: "In stock" },
  { id: 8, name: "Jordan 1 Chicago", baseUsd: 43, finalPrice: 10099, img: NEON[7], badge: "PICK 08", stock: "Few left" },
  { id: 9, name: "Samba OG", baseUsd: 36, finalPrice: 8499, img: NEON[0], badge: "PICK 09", stock: "In stock" },
  { id: 10, name: "Air Max 90", baseUsd: 38, finalPrice: 8999, img: NEON[1], badge: "PICK 10", stock: "In stock" },
  { id: 11, name: "Jordan 1 Low Grey", baseUsd: 40, finalPrice: 9499, img: NEON[2], badge: "PICK 11", stock: "In stock" },
  { id: 12, name: "Blazer Mid 77", baseUsd: 34, finalPrice: 7999, img: NEON[3], badge: "PICK 12", stock: "In stock" },
];

const CITIES = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Quetta", "Sialkot", "Gujranwala", "Islamabad", "Sargodha"];
const SIZES = [40, 41, 42, 43, 44, 45];

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedSizes, setSelectedSizes] = useState<Record<number, number>>({});
  const [form, setForm] = useState({ name: "", phone: "", address: "", city: "Karachi" });
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [orderSuccess, setOrderSuccess] = useState<OrderRecord | null>(null);
  const [trackPhone, setTrackPhone] = useState("");
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [countdown, setCountdown] = useState({ d: 0, h: 0, m: 0 });

  const topRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  // internal hidden handling - never displayed
  const TARGET_ACCOUNT = "03411836411";
  const WHATSAPP_BASE = "https://wa.me/923411836411?text=";

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const total = cart.reduce((s, i) => s + i.finalPrice * i.qty, 0);

  // last Monday 9am and next Monday
  const { lastUpdate, nextUpdate } = useMemo(() => {
    const now = new Date();
    const day = now.getDay();
    const diff = day === 1 ? 0 : day === 0 ? 6 : day - 1;
    const last = new Date(now);
    last.setDate(now.getDate() - diff);
    last.setHours(9, 0, 0, 0);
    const next = new Date(last);
    next.setDate(last.getDate() + 7);
    return { lastUpdate: last, nextUpdate: next };
  }, []);

  useEffect(() => {
    const initial: Record<number, number> = {};
    PRODUCTS.forEach(p => (initial[p.id] = 42));
    setSelectedSizes(initial);

    const tick = () => {
      const now = Date.now();
      const diff = nextUpdate.getTime() - now;
      if (diff <= 0) {
        setCountdown({ d: 0, h: 0, m: 0 });
        return;
      }
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      setCountdown({ d, h, m });
    };
    tick();
    const id = setInterval(tick, 60000);
    return () => clearInterval(id);
  }, [nextUpdate]);

  const reloadRecords = async () => {
    try {
      const res = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "records.list", args: { collection: "nzkicks_orders", limit: 100 } }),
      });
      const json = await res.json();
      if (!res.ok || json.error) throw new Error(json.error || "load failed");
      const recs = (json.data?.records || []) as { value: OrderRecord }[];
      setOrders(recs.map(r => r.value).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch {
      // silent
    }
  };

  useEffect(() => {
    reloadRecords();
  }, []);

  const createRow = async (order: OrderRecord) => {
    const res = await fetch("actions", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "records.create",
        args: { collection: "nzkicks_orders", value: order, idempotency_key: order.id },
      }),
    });
    const json = await res.json();
    if (!res.ok || json.error) throw new Error(json.error || "create failed");
    return json.data;
  };

  const addToCart = (product: Product) => {
    const size = selectedSizes[product.id] || 42;
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id && i.size === size);
      if (existing) return prev.map(i => (i.id === product.id && i.size === size ? { ...i, qty: i.qty + 1 } : i));
      return [...prev, { ...product, size, qty: 1 }];
    });
    setIsCartOpen(true);
    setErrorMsg(null);
  };

  const updateQty = (id: number, size: number, delta: number) => {
    setCart(prev =>
      prev
        .map(i => {
          if (i.id === id && i.size === size) {
            const nq = i.qty + delta;
            if (nq <= 0) return null as any;
            return { ...i, qty: nq };
          }
          return i;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handlePlaceOrder = async () => {
    if (!form.name || !form.phone || !form.address) {
      setErrorMsg("Please fill name, phone and full address");
      return;
    }
    if (cart.length === 0) {
      setErrorMsg("Cart is empty");
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    const orderId = `NZK-${Date.now()}-${Math.floor(Math.random() * 9000 + 1000)}`;
    // hidden calculation: final includes 12% over base. hidden = total - total/1.12
    const hiddenAmount = Math.round(total - total / 1.12);
    const orderValue: OrderRecord = {
      id: orderId,
      customer: { name: form.name, phone: form.phone, address: form.address, city: form.city },
      items: cart.map(c => ({ name: c.name, size: c.size, qty: c.qty, price: c.finalPrice })),
      total,
      hiddenAmount,
      targetAccount: TARGET_ACCOUNT,
      status: "Confirmed",
      createdAt: new Date().toISOString(),
    };

    try {
      await createRow(orderValue);
      await reloadRecords();
      setOrderSuccess(orderValue);
      setCart([]);
      const itemsText = orderValue.items.map(i => `${i.name} EU ${i.size} x${i.qty}`).join('%0A');
      const msg = `NZKICKS ORDER ${orderId}%0A%0A${itemsText}%0A%0ATotal: Rs ${total}%0A%0A${form.name}%0A${form.phone}%0A${form.city} - ${form.address}`;
      window.open(`${WHATSAPP_BASE}${msg}`, '_blank');
      setIsCartOpen(false);
    } catch (e: any) {
      setErrorMsg(e.message || "Order failed");
    } finally {
      setBusy(false);
    }
  };

  const filteredOrders = trackPhone
    ? orders.filter(o => o.customer.phone.includes(trackPhone) || o.id.includes(trackPhone))
    : orders.slice(0, 6);

  return (
    <div
      data-safe-area-inset-root
      className="min-h-screen w-full bg-white text-black overflow-x-clip"
      style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)', background: '#ffffff', color: '#0a0a0a' }}
    >
      {/* Header */}
      <header
        data-safe-area-sticky-top
        className="sticky z-40 backdrop-blur-xl bg-white/85 border-b border-[#ecece8]"
        style={{ top: 'var(--safe-area-inset-top)' }}
      >
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 h-[68px] flex items-center justify-between">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-3">
            <span className="font-[900] tracking-[-0.06em] text-[26px] leading-none" style={{ fontFamily: 'Syne, sans-serif' }}>
              NZKICKS
            </span>
            <span className="hidden sm:inline-flex h-5 items-center rounded-full border border-black/10 px-2 text-[9px] font-[800] tracking-[0.18em]">PAKISTAN</span>
          </button>
          <div className="flex items-center gap-2">
            <nav className="hidden md:flex items-center gap-1 mr-2">
              <button onClick={() => topRef.current?.scrollIntoView({ behavior: 'smooth' })} className="text-[11px] font-[700] tracking-[0.12em] px-3 py-1.5 rounded-full hover:bg-black hover:text-white transition">
                TOP 12
              </button>
              <button onClick={() => trackRef.current?.scrollIntoView({ behavior: 'smooth' })} className="text-[11px] font-[700] tracking-[0.12em] px-3 py-1.5 rounded-full border border-black/10 hover:bg-black hover:text-white transition">
                TRACK
              </button>
            </nav>
            <button
              onClick={() => setIsCartOpen(true)}
              className="h-9 sm:h-10 px-4 rounded-full bg-black text-white flex items-center gap-2 text-[12px] font-[700] tracking-wide hover:bg-[#111]"
            >
              CART <span className="w-5 h-5 bg-white text-black rounded-full grid place-items-center text-[11px] font-[900]">{cartCount}</span>
            </button>
          </div>
        </div>
        <div className="md:hidden border-t border-[#ecece8] h-9 flex items-center gap-2 px-4 overflow-x-auto">
          <button onClick={() => topRef.current?.scrollIntoView({ behavior: 'smooth' })} className="shrink-0 text-[11px] font-[800] tracking-widest px-3 py-1 rounded-full bg-black text-white">
            TOP 12 NEON
          </button>
          <span className="shrink-0 text-[10px] tracking-[0.12em] text-black/50 font-[700]">NZKICKS PICKS WEEKLY • EVERY MONDAY</span>
        </div>
      </header>

      {/* Hero - premium white with neon image */}
      <section className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 pt-4">
        <div className="relative rounded-[28px] overflow-hidden bg-[#050505] min-h-[540px] sm:min-h-[600px] flex">
          <img src={`${neon1}#hero-nzkicks-neon`} alt="NZKICKS neon kicks" className="absolute inset-0 w-full h-full object-cover opacity-[0.9]" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/75 to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
          {/* neon glow accents */}
          <div className="absolute -bottom-24 -right-24 w-[420px] h-[420px] rounded-full bg-[#00ff88] blur-[120px] opacity-[0.18] pointer-events-none" />
          <div className="absolute top-10 right-10 w-[220px] h-[220px] rounded-full bg-[#00ffcc] blur-[80px] opacity-[0.15] pointer-events-none" />

          <div className="relative z-10 p-6 sm:p-10 lg:p-12 w-full flex flex-col justify-between max-w-[720px]">
            <div className="flex flex-wrap gap-2">
              <span className="inline-flex bg-white text-black rounded-full px-3 py-1.5 text-[10px] font-[900] tracking-[0.14em]">NZKICKS • TOP 12 NEON EDITION</span>
              <span className="inline-flex bg-white/10 border border-white/20 backdrop-blur text-white rounded-full px-3 py-1.5 text-[10px] font-[800] tracking-[0.14em]">WEEKLY UPDATE • MONDAY 9AM</span>
            </div>
            <div className="mt-auto">
              <h1 className="text-white font-[900] leading-[0.86] tracking-[-0.05em] text-[44px] sm:text-[68px] lg:text-[78px]" style={{ fontFamily: 'Syne, sans-serif' }}>
                TOP 12
                <br />
                <span className="text-white/90">NEON</span>
                <br />
                PICKS
              </h1>
              <p className="mt-4 text-white/70 text-[14px] sm:text-[15px] leading-[1.6] max-w-[460px]">Neon background display, premium pairs, weekly refreshed. All pairs ready to ship. Built for NZKICKS.</p>
              <div className="mt-7 flex flex-wrap gap-3">
                <button
                  onClick={() => topRef.current?.scrollIntoView({ behavior: 'smooth' })}
                  className="h-[46px] px-7 rounded-full bg-white text-black font-[900] text-[12px] tracking-[0.08em] hover:bg-[#00ff88] hover:text-black transition"
                >
                  SHOP TOP 12 →
                </button>
                <button onClick={() => trackRef.current?.scrollIntoView({ behavior: 'smooth' })} className="h-[46px] px-6 rounded-full border border-white/20 bg-white/10 backdrop-blur text-white font-[700] text-[12px]">
                  TRACK YOUR ORDER
                </button>
              </div>
              <div className="mt-8 grid grid-cols-3 gap-3 max-w-[420px]">
                <div className="rounded-[12px] bg-white/10 border border-white/10 backdrop-blur p-3">
                  <div className="text-[9px] font-[800] tracking-[0.14em] text-white/50">LAST UPDATE</div>
                  <div className="text-[13px] font-[800] text-white mt-1">{lastUpdate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</div>
                </div>
                <div className="rounded-[12px] bg-white/10 border border-white/10 backdrop-blur p-3">
                  <div className="text-[9px] font-[800] tracking-[0.14em] text-white/50">NEXT REFRESH</div>
                  <div className="text-[13px] font-[800] text-white mt-1">{countdown.d}d {countdown.h}h {countdown.m}m</div>
                </div>
                <div className="rounded-[12px] bg-white text-black p-3">
                  <div className="text-[9px] font-[800] tracking-[0.14em] text-black/50">EDITION</div>
                  <div className="text-[13px] font-[900] mt-1">NEON • 12</div>
                </div>
              </div>
            </div>
          </div>

          {/* right small preview */}
          <div className="hidden lg:block absolute right-10 top-1/2 -translate-y-1/2 w-[320px]">
            <div className="rounded-[22px] bg-white p-3 shadow-[0_20px_80px_rgba(0,0,0,0.4)]">
              <div className="rounded-[16px] overflow-hidden bg-black relative aspect-[4/3]">
                <img src={`${neon2}#hero-preview`} alt="Neon preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 ring-1 ring-white/10 rounded-[16px]" />
                <div className="absolute bottom-3 left-3 bg-white text-black rounded-full px-2.5 py-1 text-[10px] font-[800]">NEON DISPLAY</div>
              </div>
              <div className="p-3">
                <div className="text-[11px] font-[800] tracking-[0.12em] text-black/40">NZKICKS WEEKLY</div>
                <div className="font-[800] text-[16px] tracking-tight mt-1">Top 12 • Neon Background</div>
                <div className="text-[12px] text-black/60 mt-1">Updated every Monday 9AM • nzkicks.netlify.app</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Weekly bar - NZKICKS only */}
      <section className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 py-5">
        <div className="rounded-[16px] border border-[#ecece8] bg-[#fbfbfa] px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-black text-white grid place-items-center font-[900] text-[12px]">↻</div>
            <div>
              <div className="font-[900] text-[12px] tracking-[0.08em]">NZKICKS PICKS WEEKLY</div>
              <div className="text-[11px] text-black/50 mt-0.5">Every Monday 9AM • Top 12 refreshed • Neon display ready</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-[10px] font-[800] tracking-[0.14em] text-black/40">NEXT UPDATE IN</div>
            <div className="flex gap-1.5">
              {[
                { l: 'D', v: countdown.d },
                { l: 'H', v: countdown.h },
                { l: 'M', v: countdown.m },
              ].map(u => (
                <div key={u.l} className="min-w-[36px] h-8 rounded-[10px] bg-black text-white grid place-items-center px-2">
                  <span className="text-[12px] font-[900]">
                    {String(u.v).padStart(2, '0')}<span className="text-[9px] ml-0.5 opacity-60">{u.l}</span>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Top 12 Neon Grid */}
      <section ref={topRef} className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 pb-8">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="font-[900] tracking-[-0.05em] leading-[0.9] text-[28px] sm:text-[44px]" style={{ fontFamily: 'Syne, sans-serif' }}>
              TOP 12 • NEON
            </h2>
            <p className="text-[12px] text-black/50 mt-2">Neon background edition • 12 pairs only • Updated {lastUpdate.toLocaleDateString()}</p>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-[10px] font-[800] tracking-[0.14em] text-black/40">
            <span className="w-2 h-2 bg-[#00ff88] rounded-full shadow-[0_0_10px_#00ff88]" /> NZKICKS • READY TO SHIP
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
          {PRODUCTS.map(p => (
            <div
              key={p.id}
              className="group relative rounded-[24px] border border-[#ecece8] bg-white overflow-hidden hover:shadow-[0_18px_60px_rgba(0,0,0,0.10)] hover:border-black/15 transition-all flex flex-col"
            >
              {/* neon image wrapper */}
              <div className="relative aspect-[1/1] bg-[#060606] overflow-hidden">
                {/* neon glow layers */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#00ff88]/15 via-transparent to-[#00ffcc]/10 opacity-60 group-hover:opacity-90 transition-opacity" />
                <div className="absolute -inset-10 bg-[#00ff88] blur-[60px] opacity-[0.08] group-hover:opacity-[0.18] transition-opacity pointer-events-none" />
                <img
                  src={`${p.img}#nzkicks-neon-${p.id}-${p.name.replace(/\s+/g, '-')}`}
                  alt={p.name}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.07] transition-transform duration-[900ms]"
                />
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-none pointer-events-none" />
                <div className="absolute top-3 left-3 flex gap-1.5">
                  <span className="bg-white text-black text-[10px] font-[900] tracking-[0.12em] px-2.5 py-1 rounded-full shadow-sm">{p.badge}</span>
                  <span className="bg-black/80 backdrop-blur border border-white/10 text-white text-[10px] font-[800] px-2.5 py-1 rounded-full">NEON</span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center">
                  <div className="bg-white/95 backdrop-blur rounded-full px-3 py-1 text-[11px] font-[700] shadow">✓ {p.stock}</div>
                  <div className="bg-black text-white rounded-full w-7 h-7 grid place-items-center text-[10px] font-[900]">#{String(p.id).padStart(2, '0')}</div>
                </div>
                {/* neon border glow */}
                <div className="absolute inset-0 rounded-none pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500 shadow-[inset_0_0_0_1px_rgba(0,255,136,0.5),0_0_30px_rgba(0,255,136,0.25)]" />
              </div>

              <div className="p-4 flex flex-col flex-1">
                <h3 className="font-[800] text-[14px] leading-tight tracking-[-0.01em]">{p.name}</h3>
                <div className="mt-2 flex items-center justify-between">
                  <div className="text-[18px] font-[900] tracking-[-0.02em]">Rs {p.finalPrice.toLocaleString()}</div>
                  <div className="text-[10px] font-[700] tracking-[0.12em] text-black/40">NZKICKS PRICE</div>
                </div>

                <div className="mt-3">
                  <div className="text-[10px] font-[800] tracking-[0.14em] text-black/40 mb-2">SIZE</div>
                  <div className="flex flex-wrap gap-1.5">
                    {SIZES.map(sz => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSizes(s => ({ ...s, [p.id]: sz }))}
                        className={`w-[34px] h-[30px] rounded-full border text-[11px] font-[800] transition ${
                          selectedSizes[p.id] === sz ? 'bg-black text-white border-black' : 'border-[#ecece8] bg-white hover:border-black'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => addToCart(p)}
                  className="mt-4 w-full h-[40px] rounded-full bg-black text-white font-[800] text-[11px] tracking-[0.08em] flex items-center justify-center gap-2 hover:bg-[#111] group-hover:bg-black transition-colors"
                >
                  ADD TO CART • EU {selectedSizes[p.id] || 42}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Track */}
      <section ref={trackRef} className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 pb-12">
        <div className="rounded-[24px] border border-[#ecece8] bg-white p-6 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-[900] tracking-[-0.03em] text-[22px] sm:text-[26px]" style={{ fontFamily: 'Syne, sans-serif' }}>
                TRACK YOUR ORDER
              </h3>
              <p className="text-[12px] text-black/50 mt-1">Enter phone or Order ID to check status on NZKICKS</p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <input
                value={trackPhone}
                onChange={e => setTrackPhone(e.target.value)}
                placeholder="Phone or Order ID"
                className="flex-1 sm:w-[260px] h-[44px] rounded-full border border-[#ecece8] px-5 text-[13px] outline-none focus:border-black"
              />
              <button onClick={() => {}} className="h-[44px] px-6 rounded-full bg-black text-white text-[12px] font-[800]">
                SEARCH
              </button>
            </div>
          </div>

          <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredOrders.map(o => (
              <div key={o.id} className="rounded-[16px] border border-[#ecece8] bg-[#fbfbfa] p-4">
                <div className="flex justify-between items-start gap-2">
                  <div className="font-[800] text-[11px] tracking-wide">{o.id}</div>
                  <div className="text-[10px] font-[800] px-2 py-1 rounded-full bg-black text-white">{o.status}</div>
                </div>
                <div className="mt-2 text-[12px] font-[700]">{o.customer.name} • {o.customer.city}</div>
                <div className="text-[11px] text-black/50">{o.customer.phone} • {o.items.length} pairs</div>
                <div className="mt-3 rounded-[10px] bg-white border border-[#ecece8] p-2.5 flex justify-between items-center">
                  <span className="text-[10px] font-[800] tracking-[0.12em] text-black/40">TOTAL</span>
                  <span className="font-[900] text-[13px]">Rs {o.total.toLocaleString()}</span>
                </div>
                <div className="mt-2 text-[10px] text-black/40">{new Date(o.createdAt).toLocaleString()}</div>
              </div>
            ))}
            {filteredOrders.length === 0 && (
              <div className="col-span-full text-center py-10 text-[13px] text-black/50">No orders yet on NZKICKS. Place your first order.</div>
            )}
          </div>
        </div>
      </section>

      {/* Footer - only NZKICKS */}
      <footer className="border-t border-[#ecece8] bg-black text-white">
        <div className="mx-auto max-w-[1400px] px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid sm:grid-cols-3 gap-8">
            <div>
              <div className="font-[900] text-[26px] tracking-[-0.05em]" style={{ fontFamily: 'Syne, sans-serif' }}>
                NZKICKS
              </div>
              <div className="text-[11px] tracking-[0.18em] opacity-50 mt-1">TOP 12 • NEON EDITION • WEEKLY PICKS</div>
              <p className="mt-4 text-[13px] opacity-70 leading-[1.6] max-w-[320px]">Neon display, premium pairs, ready to ship. Every Monday refreshed on NZKICKS.</p>
            </div>
            <div className="text-[13px] leading-[1.8]">
              <div className="font-[800] text-[11px] tracking-[0.15em] opacity-40 mb-3">INFO</div>
              <div>nzkicks.netlify.app</div>
              <div>Instagram @itzkeyde</div>
              <div>NZKICKS Pakistan</div>
              <div className="mt-2 text-[11px] opacity-60">Weekly update • Monday 9AM</div>
            </div>
            <div className="text-[13px] leading-[1.8]">
              <div className="font-[800] text-[11px] tracking-[0.15em] opacity-40 mb-3">SUPPORT</div>
              <div>Track Order</div>
              <div>Top 12 Neon Picks</div>
              <div>Order on NZKICKS</div>
              <div className="mt-2 text-[11px] opacity-60">Built for Netlify • Premium • Error-free</div>
            </div>
          </div>
          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row justify-between gap-3 text-[11px] opacity-50">
            <div>© {new Date().getFullYear()} NZKICKS • Neon Edition • Weekly Top 12</div>
            <div className="flex gap-4">
              <span>NZKICKS</span>
              <span>Top 12</span>
              <span>Neon</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <div className={`fixed inset-0 z-[100] transition ${isCartOpen ? 'visible' : 'invisible'}`}>
        <div onClick={() => setIsCartOpen(false)} className={`absolute inset-0 bg-black/50 backdrop-blur-sm transition ${isCartOpen ? 'opacity-100' : 'opacity-0'}`} />
        <div
          className={`absolute top-0 right-0 h-full w-[96%] sm:w-[460px] bg-white shadow-[-20px_0_80px_rgba(0,0,0,0.25)] flex flex-col transition-transform duration-300 ${
            isCartOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="h-[68px] px-6 flex items-center justify-between border-b border-[#ecece8] shrink-0">
            <div className="flex items-center gap-3">
              <div className="font-[900] text-[16px] tracking-tight" style={{ fontFamily: 'Syne, sans-serif' }}>
                CART • NZKICKS
              </div>
              <div className="text-[11px] bg-black text-white rounded-full px-2.5 py-1 font-[800]">{cartCount} ITEMS</div>
            </div>
            <button onClick={() => setIsCartOpen(false)} className="w-8 h-8 rounded-full border border-[#ecece8] grid place-items-center hover:bg-black hover:text-white transition">
              ✕
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {cart.length === 0 ? (
              <div className="p-10 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-[#f6f6f3] grid place-items-center text-[22px]">🛒</div>
                <div className="mt-4 font-[800]">Cart empty — add from Top 12 Neon</div>
                <div className="text-[13px] text-black/50 mt-1">Premium pairs, neon display, ready to ship</div>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setTimeout(() => topRef.current?.scrollIntoView({ behavior: 'smooth' }), 120);
                  }}
                  className="mt-6 h-[42px] px-6 rounded-full bg-black text-white font-[800] text-[12px]"
                >
                  BROWSE TOP 12
                </button>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {cart.map(item => (
                  <div key={`${item.id}-${item.size}`} className="flex gap-3 rounded-[16px] border border-[#ecece8] bg-[#fbfbfa] p-3">
                    <img src={`${item.img}#cart-${item.id}-${item.size}`} alt={item.name} className="w-[72px] h-[72px] rounded-[12px] object-cover bg-[#0a0a0a]" />
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between gap-2">
                        <div className="font-[800] text-[13px] leading-tight truncate">{item.name}</div>
                        <div className="font-[900] text-[13px]">Rs {(item.finalPrice * item.qty).toLocaleString()}</div>
                      </div>
                      <div className="text-[11px] text-black/50 mt-1">EU {item.size} • NZKICKS price</div>
                      <div className="mt-2 flex items-center gap-2">
                        <button onClick={() => updateQty(item.id, item.size, -1)} className="w-7 h-7 rounded-full border border-[#ecece8] bg-white grid place-items-center">
                          −
                        </button>
                        <div className="w-8 text-center font-[800] text-[13px]">{item.qty}</div>
                        <button onClick={() => updateQty(item.id, item.size, 1)} className="w-7 h-7 rounded-full bg-black text-white grid place-items-center">
                          +
                        </button>
                        <button onClick={() => setCart(c => c.filter(x => !(x.id === item.id && x.size === item.size)))} className="ml-auto text-[11px] font-[700] text-black/50 hover:text-black hover:underline">
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                <div className="pt-4">
                  <div className="font-[900] text-[12px] tracking-[0.08em]">DELIVERY DETAILS • NZKICKS</div>
                  <div className="mt-3 grid gap-3">
                    <input
                      value={form.name}
                      onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                      placeholder="Full Name *"
                      className="h-[44px] rounded-[12px] border border-[#ecece8] bg-white px-4 text-[13px] outline-none focus:border-black"
                    />
                    <input
                      value={form.phone}
                      onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                      placeholder="Phone (WhatsApp) *"
                      className="h-[44px] rounded-[12px] border border-[#ecece8] bg-white px-4 text-[13px] outline-none focus:border-black"
                    />
                    <input
                      value={form.address}
                      onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
                      placeholder="Complete Address *"
                      className="h-[44px] rounded-[12px] border border-[#ecece8] bg-white px-4 text-[13px] outline-none focus:border-black"
                    />
                    <select
                      value={form.city}
                      onChange={e => setForm(f => ({ ...f, city: e.target.value }))}
                      className="h-[44px] rounded-[12px] border border-[#ecece8] bg-white px-4 text-[13px] outline-none focus:border-black"
                    >
                      {CITIES.map(c => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  {errorMsg && <div className="mt-3 text-[12px] font-[700] text-red-600 bg-red-50 border border-red-200 rounded-[10px] p-3">{errorMsg}</div>}
                </div>
              </div>
            )}
          </div>

          {cart.length > 0 && (
            <div className="border-t border-[#ecece8] bg-[#fbfbfa] p-5 shrink-0">
              <div className="space-y-1.5 text-[13px]">
                <div className="flex justify-between">
                  <span className="text-black/50">Subtotal</span>
                  <span className="font-[700]">Rs {total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[15px] font-[900] pt-2 border-t border-dashed border-[#ecece8]">
                  <span>Total</span>
                  <span>Rs {total.toLocaleString()}</span>
                </div>
              </div>
              <button
                disabled={busy}
                onClick={handlePlaceOrder}
                className="mt-4 w-full h-[48px] rounded-full bg-black text-white font-[900] text-[12px] tracking-[0.08em] flex items-center justify-center gap-2 hover:bg-[#111] disabled:opacity-60 transition"
              >
                {busy ? "PLACING..." : "ORDER ON NZKICKS"}
              </button>
              <div className="mt-3 text-[11px] text-center text-black/50 leading-[1.4]">Order placed on NZKICKS • Tracking available shortly</div>
            </div>
          )}
        </div>
      </div>

      {/* Success */}
      {orderSuccess && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div onClick={() => setOrderSuccess(null)} className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="relative w-full max-w-[440px] bg-white rounded-[24px] p-6 sm:p-8 shadow-2xl animate-[in_0.3s_ease]">
            <div className="w-12 h-12 rounded-full bg-black text-white grid place-items-center text-[20px] mx-auto">✓</div>
            <h3 className="text-center text-[22px] font-[900] mt-4" style={{ fontFamily: 'Syne, sans-serif' }}>
              Order placed successfully on NZKICKS
            </h3>
            <p className="text-center text-[12px] text-black/50 mt-2">Thank you for shopping on NZKICKS • Top 12 Neon</p>

            <div className="mt-6 rounded-[14px] bg-[#f6f6f3] border border-[#ecece8] p-4 text-[12px] space-y-2">
              <div className="flex justify-between">
                <span className="text-black/50">Order ID</span>
                <span className="font-[800]">{orderSuccess.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/50">Total</span>
                <span className="font-[900]">Rs {orderSuccess.total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/50">Items</span>
                <span className="font-[700]">{orderSuccess.items.length} pairs</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-2">
              <button onClick={() => setOrderSuccess(null)} className="h-[44px] rounded-full border border-[#ecece8] font-[800] text-[12px]">
                CONTINUE SHOPPING
              </button>
              <button
                onClick={() => {
                  setOrderSuccess(null);
                  trackRef.current?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="h-[44px] rounded-full bg-black text-white font-[800] text-[12px]"
              >
                TRACK ORDER
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`@keyframes in{from{transform:translateY(8px);opacity:0}to{transform:translateY(0);opacity:1}}`}</style>
    </div>
  );
}
